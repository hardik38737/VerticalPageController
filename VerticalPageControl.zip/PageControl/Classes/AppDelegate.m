#import "AppDelegate.h"
#import "ContentController.h"

@implementation AppDelegate

@synthesize window, contentController;

- (void)dealloc
{
    [window release];
    [contentController release];
    
    [super dealloc];
}

- (void)applicationDidFinishLaunching:(UIApplication *)application
{
	NSString *nibTitle = @"PadContent";
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone)
	{
		nibTitle = @"PhoneContent";
    }
    [[NSBundle mainBundle] loadNibNamed:nibTitle owner:self options:nil];
    
    [self.window addSubview:self.contentController.view];
	[window makeKeyAndVisible];
}

@end
