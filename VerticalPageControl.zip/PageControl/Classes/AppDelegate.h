#import <UIKit/UIKit.h>

@class ContentController;

@interface AppDelegate : NSObject <UIApplicationDelegate>
{
	UIWindow *window;
    ContentController *contentController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ContentController *contentController;

@end

